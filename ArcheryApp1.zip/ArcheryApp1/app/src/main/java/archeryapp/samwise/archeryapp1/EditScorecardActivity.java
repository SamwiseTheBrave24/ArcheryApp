package archeryapp.samwise.archeryapp1;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Color;
import android.support.constraint.ConstraintLayout;
import android.support.constraint.ConstraintSet;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class EditScorecardActivity extends AppCompatActivity {

    private static final int WIDTH = 150;
    private static final int HEIGHT = 150;
    private static final int BUTTON_TEXT_SIZE = 12;
    private static final int SCORE_TEXT_SIZE = 18;
    private int currentShot;
    private int previousShot;
    private String location;
    private int totalShotNumber;
    private Scorecard scorecard;

    @SuppressLint("ResourceType")
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        //Grab scorecard info from the bundle and create the scorecard
        Intent intent = getIntent();
        Bundle scorecardInfo = intent.getBundleExtra("ScorecardInfo");
        location = scorecardInfo.getString("Location");
        totalShotNumber = scorecardInfo.getInt("TotalShotNumber");
        scorecard = new Scorecard(location, totalShotNumber);
        currentShot = 1;

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_scorecard);

        createUI();
    }

/*****************************************************************************************************************/

    //onClick functions
    private View.OnClickListener setCurrentShot (Button button)
    {
        return new View.OnClickListener()
        {
            public void onClick(View view)
            {
                //previousShot = currentShot;                 //Sets previous shot since we are changing the currentShot
                Button previousShotButton = findViewById(currentShot);
                previousShotButton.setBackgroundColor(Color.WHITE);
                //Needs to pull in the button label as this is a generic function
                currentShot = view.getId();
                TextView updateCurrentShotBox = findViewById(R.id.testCurrentShot);
                String sCurrentShot = Integer.toString(currentShot);
                updateCurrentShotBox.setText(sCurrentShot);
                view.setBackgroundColor(Color.YELLOW);
            }

        };
    }

    private void editPoints(int points)
    {
        String sString = Integer.toString(points);
        TextView scoreBox = findViewById(currentShot + 100);
        String sCurrentScore = scoreBox.getText().toString();

        if (sCurrentScore.isEmpty())
        {
            scorecard.addPoints(currentShot, points);             //used for live
        } else
        {
            int pointChange = Integer.parseInt(sCurrentScore);
            Log.d(Integer.toString(pointChange), "--- Points change");
            scorecard.changePoints(currentShot, points);     //used for live
            Log.d(Integer.toString(scorecard.getTotalScore()), "--- CurrentScore");
        }

        scoreBox.setText(sString);
        TextView totalScoreBox = findViewById(R.id.totalScoreBox);
        //totalScoreBox.setText(sString);                             //used for testing UI
        totalScoreBox.setText(Integer.toString(scorecard.getTotalScore()));     //used for live
        moveFocusToNextShot();

    }

    private void moveFocusToNextShot ()
    {
        //previousShot = currentShot;                 //Sets previous shot since we are changing the currentShot
        if (currentShot != totalShotNumber)
        {
            Button previousShotButton = findViewById(currentShot);
            previousShotButton.setBackgroundColor(Color.WHITE);
            currentShot += 1;
            Button nextShotButton = findViewById(currentShot);
            nextShotButton.setBackgroundColor(Color.YELLOW);
            TextView currentShotBox = findViewById(R.id.testCurrentShot);
            currentShotBox.setText(Integer.toString(currentShot));
        }
    }


    @Override
    public void onBackPressed()
    {
        //Do nothing!!
    }


/*******************************************************************************************************************/

    //UI creation functions
    //This function creates and edits all of the buttons and TextViews on this activity
    private void createUI ()
    {
        //Setting attributes for elements predefined in XML, starting left to right, top down

        //Location
        TextView locationBox = findViewById(R.id.locationBox);
        locationBox.setGravity(Gravity.CENTER_VERTICAL);
        //locationBox.setText("sampleLocation");          //For testing UI
        locationBox.setText(location);                //For live

        //Date
        TextView dateBox = findViewById(R.id.dateBox);
        dateBox.setGravity(Gravity.CENTER_VERTICAL);
        //dateBox.setText("04/20/18");                    //For testing UI
        dateBox.setText(scorecard.getDate());    //For live

        //Total Score
        TextView totalScoreBox = findViewById(R.id.totalScoreBox);
        totalScoreBox.setGravity(Gravity.CENTER_VERTICAL | Gravity.CENTER_HORIZONTAL);
        totalScoreBox.setText("0");                     //Score will always be 0 on create

        //Add points
        Button zeroPoints = findViewById(R.id.plus0Points);
        zeroPoints.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v) {
                editPoints(0);
            }
        });
        Button fivePoints = findViewById(R.id.plus5Points);
        fivePoints.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v) {
                editPoints(5);
            }
        });
        Button eightPoints = findViewById(R.id.plus8Points);
        eightPoints.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v) {
                editPoints(8);
            }
        });
        Button tenPoints = findViewById(R.id.plus10Points);
        tenPoints.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v) {
                editPoints(10);
            }
        });
        Button twelvePoints = findViewById(R.id.plus12Points);
        twelvePoints.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v) {
                editPoints(12);
            }
        });

        //Save the shoot and close out of the activity
        Button saveAndFinish = findViewById(R.id.saveButton);


        //Create the scorecard grid
        //createScorecardGrid(40);            //For testing UI
        createScorecardGrid(totalShotNumber);         //For live

    }

    //Function creates the grid for the scorecard. Calls createIndividualShot and createFirstShot multiple times to create the grid based on number of shots
    private void createScorecardGrid (int numShots)
    {
        //Used to grab the height and width of the screen
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int height = displayMetrics.heightPixels;       //Probably not needed
        int width = displayMetrics.widthPixels;         //Start with no margins

        //Need to get dimensions of the grid
        int shotsPerRow = width/WIDTH;                              //Defines the number of shots per row used for creating the grid as some screens are larger than others
        int numOfRows = numShots/shotsPerRow;                      //Will need this to define number of for loops we need to make the grid
        int shotsInFinalRow = numShots%shotsPerRow;                //This may be needed for the final part of the for loop to create the leftover shots

        //Grid creation process
        int shotCounter = 1;                //This will be used to set the Ids for the buttons and TextViews
        for (int i = 1; i <= numOfRows; i++)     //Does loop for number of rows - after the loop, we need to check if there is a remainder
        {
           if (i == 1)                      //Need to check if this is the first row as the upperConstraint is different (based on locationBox)
           {
               createFirstShot(shotCounter, shotCounter + 100, R.id.locationBox, 0);
               for (int x = 2; x <= shotsPerRow; x++)
               {
                   shotCounter += 1;
                   createIndividualShot(shotCounter, shotCounter + 100, R.id.locationBox, 0);
               }
           }else                            //upperConstriant for the rest is based on the TextView above the button
           {
               shotCounter += 1;
               createFirstShot(shotCounter, shotCounter + 100, shotCounter - shotsPerRow + 100, 0);
               for (int x = 2; x <= shotsPerRow; x++)
               {
                   shotCounter += 1;
                   createIndividualShot(shotCounter, shotCounter + 100, shotCounter - shotsPerRow + 100, 0);
               }
           }
        }
        if (shotsInFinalRow > 0 && numOfRows > 0)            //Sometimes there will not be enough shots left to fill a row
        {
            shotCounter += 1;
            createFirstShot(shotCounter, shotCounter + 100, shotCounter - shotsPerRow + 100, 0);
            for (int x = 2; x <= shotsInFinalRow; x++)
            {
                shotCounter += 1;
                createIndividualShot(shotCounter, shotCounter + 100, shotCounter - shotsPerRow + 100, 0);
            }
        }else if (shotsInFinalRow > 0 && numOfRows == 0)
        {
            createFirstShot(shotCounter, shotCounter + 100, R.id.locationBox, 0);
            for (int i = 2; i <= totalShotNumber; i++)
            {
                shotCounter += 1;
                createIndividualShot(shotCounter, shotCounter + 100, R.id.locationBox, 0);
            }
        }

    }

    //Creates the first shot Button and TextView in a row because the left constraint is based on phone screen and not previous shot
    private void createFirstShot (int shotID, int scoreID, int upperConstraint, int upperMargin)
    {

        //This is used to create the first shot in the row. It is needed because it uses the layout for ConstraintSet.LEFT

        String textString = Integer.toString(shotID);
        ConstraintLayout layout = (ConstraintLayout) findViewById(R.id.constraintLayout);
        ConstraintSet set = new ConstraintSet();
        ConstraintLayout.LayoutParams scoreSize = new ConstraintLayout.LayoutParams(WIDTH, HEIGHT);
        ConstraintLayout.LayoutParams buttonSize = new ConstraintLayout.LayoutParams(WIDTH, HEIGHT);

        //create button
        Button shotButton = new Button(this);
        shotButton.setId(shotID);
        shotButton.setTag(shotID);                              //Might not need this. Added in case i need to use getTag() for onClick functions
        shotButton.setText(textString);
        shotButton.setTextSize(BUTTON_TEXT_SIZE);
        shotButton.setLayoutParams(buttonSize);
        //These two values highlight the button when pressed
        //shotButton.setBackgroundResource(R.drawable.button_background);  //button_background has the code to change the color when pressed, focus, and default
        if (shotID == 1)                                        //Set the background of the very first shot to yellow since currentShot = 1
        {
            shotButton.setBackgroundColor(Color.YELLOW);
        }else
        {
            shotButton.setBackgroundColor(Color.WHITE);
        }
        //shotButton.setFocusableInTouchMode(true);    //This allows the button to keep the focus after clicked, but this makes the user have to double click to activate the onClick function
                                                        //This has something to do with the onTouchListener (what sets the focus) consuming the action
        //This activates the specified function when the button is clicked
        shotButton.setOnClickListener(setCurrentShot(shotButton));
        //shotButton.setOnFocusChangeListener();        //This might resolve the setFocusable issue

        //Add button to layout
        layout.addView(shotButton);
        set.clone(layout);
        set.connect(shotButton.getId(), ConstraintSet.LEFT, layout.getId(), ConstraintSet.RIGHT, 0);      //Can use left/right here because there is no margin anyway
        set.connect(shotButton.getId(), ConstraintSet.TOP, upperConstraint, ConstraintSet.BOTTOM, upperMargin);
        set.applyTo(layout);

        //Create numerical text box
        TextView scoreBox = new TextView(this);
        scoreBox.setId(scoreID);
        scoreBox.setTag(scoreID);                                //Might not need this. Added in case i need to use getTag() editting the text
        scoreBox.setLayoutParams(scoreSize);
        scoreBox.setTextSize(SCORE_TEXT_SIZE);
        scoreBox.setTextColor(Color.BLACK);
        scoreBox.setGravity(Gravity.CENTER_VERTICAL | Gravity.CENTER_HORIZONTAL);
        //scoreBox.setText(textString);
        scoreBox.setBackgroundResource(R.drawable.border);

        //Below is what sets the textview to the layout and sets its "position"
        layout.addView(scoreBox);
        set.clone(layout);
        set.connect(scoreBox.getId(), ConstraintSet.TOP, shotButton.getId(), ConstraintSet.BOTTOM, 0);
        set.connect(scoreBox.getId(), ConstraintSet.LEFT, layout.getId(), ConstraintSet.RIGHT, 0);
        set.applyTo(layout);
    }

    //Creates shot Button and TextView next to the previous shot
    private void createIndividualShot (int shotID, int scoreID, int upperConstraint, int upperMargin)
    {
        //Creates button with the shot number and text box below it
        //Textbox text size = 24 (and Bold)

        String buttonText = Integer.toString(shotID);
        Button previousShot = findViewById(shotID -1);
        TextView previousScore = findViewById(scoreID - 1);

        ConstraintLayout layout = (ConstraintLayout) findViewById(R.id.constraintLayout);
        ConstraintSet set = new ConstraintSet();
        ConstraintLayout.LayoutParams scoreSize = new ConstraintLayout.LayoutParams(WIDTH, HEIGHT);
        ConstraintLayout.LayoutParams buttonSize = new ConstraintLayout.LayoutParams(WIDTH, HEIGHT);


        //create button
        Button shotButton = new Button(this);
        shotButton.setId(shotID);
        shotButton.setTag(shotID);                                  //Might not need this. Added in case i need to use getTag() for onClick functions
        shotButton.setOnClickListener(setCurrentShot(shotButton));
        shotButton.setText(buttonText);
        shotButton.setTextSize(BUTTON_TEXT_SIZE);
        shotButton.setLayoutParams(buttonSize);
        shotButton.setBackgroundColor(Color.WHITE);
        //shotButton.setBackgroundResource(R.drawable.button_background);  //button_background has the code to change the color when pressed, focus, and default
        shotButton.setOnClickListener(setCurrentShot(shotButton));

        //Add button to layout
        layout.addView(shotButton);
        set.clone(layout);
        set.connect(shotButton.getId(), ConstraintSet.LEFT, previousShot.getId(), ConstraintSet.RIGHT, 0);      //Can use left/right here because there is no margin anyway
        set.connect(shotButton.getId(), ConstraintSet.TOP, upperConstraint, ConstraintSet.BOTTOM, upperMargin);
        set.applyTo(layout);

        //Create numerical text box
        TextView scoreBox = new TextView(this);
        scoreBox.setId(scoreID);
        scoreBox.setTag(scoreID);                                   //Might not need this. Added in case i need to use getTag() editting the text
        scoreBox.setLayoutParams(scoreSize);
        scoreBox.setTextSize(SCORE_TEXT_SIZE);
        scoreBox.setTextColor(Color.BLACK);
        scoreBox.setGravity(Gravity.CENTER_VERTICAL | Gravity.CENTER_HORIZONTAL);
        scoreBox.setBackgroundResource(R.drawable.border);

        //Below is what sets the TextView to the layout and sets its "position"
        layout.addView(scoreBox);
        set.clone(layout);
        set.connect(scoreBox.getId(), ConstraintSet.TOP, shotButton.getId(), ConstraintSet.BOTTOM, 0);
        set.connect(scoreBox.getId(), ConstraintSet.LEFT, previousScore.getId(), ConstraintSet.RIGHT, 0);
        set.applyTo(layout);



    }
}

/* Notes

    set.connect(testText.getId(), ConstraintSet.TOP, layout.getId(), ConstraintSet.TOP, 60);        //sets the constraint for stetView.top to layout.top (basically to the top of the app
    The following line configures a constraint set in which the left-hand side of a Button view is connected to the right-hand side of an EditText view with a margin of 70dp:
    set.connect(button1.getId(), ConstraintSet.LEFT, editText1.getId(), ConstraintSet.RIGHT, 70);

    ConstraintLayout.LayoutParams clptestView = new ConstraintLayout.LayoutParams(ConstraintLayout.LayoutParams.WRAP_CONTENT, ConstraintLayout.LayoutParams.WRAP_CONTENT);
    ConstraintLayout.LayoutParams clptestView = new ConstraintLayout.LayoutParams(200, 200);

    //Successfully creates a TextView
    TextView testView = new TextView(this);
    testView.setId(100);
    testView.setText("Test");
    testView.setTextSize(10);
    ConstraintLayout.LayoutParams clptestView = new ConstraintLayout.LayoutParams(ConstraintLayout.LayoutParams.WRAP_CONTENT, ConstraintLayout.LayoutParams.WRAP_CONTENT);
    testView.setLayoutParams(clptestView);
    layout.addView(testView);
    set.clone(layout);
    set.connect(testView.getId(), ConstraintSet.TOP, layout.getId(), ConstraintSet.TOP, 60);
    set.applyTo(layout);


    //Used to find the distance between edge of item to edge of screen
    //Use this to get view position on screen
    View.getLocationOnScreen() and/or getLocationInWindow()
    //Get Screen Display
    Display display = getWindowManager().getDefaultDisplay();
    Point size = new Point();
    display.getSize(size);
    int width = size.x
    int height = size.y
    //Then calculate height - view.y-location

    //createScorecardGrid(40);          Cant create layouts before onCreate

 */
