package archeryapp.samwise.archeryapp1;

import java.lang.reflect.Array;
import java.util.Calendar;
import java.text.SimpleDateFormat;

public class Scorecard {

    //Defining variables
    public String location;
    public int totalScore;                //cumulative shoot score
    public String date;
    public int[] shotBreakdown;           //used to keep track of individual shots

    public Scorecard (String location, int totalShots)
    {
        totalScore = 0;
        date = getCurrentDate();
        this.location = location;           //need to add "this." so constructor knows which location is the defined variable
        shotBreakdown = new int[totalShots];
    }

    //Gets current date from phone and converts to readable format
    private String getCurrentDate()
    {
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
        String dateString = formatter.format(calendar.getTime());
        return dateString;
    }

    //Base function to add points
    public void addPoints (int currentShot, int score)
    {
        shotBreakdown[currentShot - 1] = score;
        totalScore += score;
    }

    public void addZeroPoints (int currentShot)
    {
        addPoints (currentShot,0);
    }

    public void addFivePoints (int currentShot)
    {
        addPoints(currentShot,5);
    }

    public void addEightPoints (int currentShot)
    {
        addPoints(currentShot, 8);
    }

    public void addTenPoints (int currentShot)
    {
        addPoints(currentShot,10);
    }

    public void addTwelvePoints(int currentShot)
    {
        addPoints(currentShot, 12);
    }

    //Function to use when you need to edit a shot number
    public void changePoints (int shotNumber, int score)
    {
        //totalScore -= shotBreakdown[shotNumber - 1];    //Need to remove the value that is currently stored for that shot
        totalScore -= getScore(shotNumber);
        shotBreakdown[shotNumber - 1] = score;          //-1 because arrays start at 0 and I plan to pull shotNumber from display box
        totalScore += score;                            //Adds new score to total
    }

    /**********************************************************************************************************************/

    //Get functions
    //Function to pull a score from a specific shot
    public int getScore (int shotNumber)
    {
        int score = shotBreakdown[shotNumber - 1];
        return score;
    }

    //Function to pull total shots on course
    public int getTotalShots ()
    {
        int totalShots = shotBreakdown.length;
        return totalShots;
    }

    public String getLocation ()
    {
        return location;
    }

    public String getDate ()
    {
        return date;
    }

    public int getTotalScore ()
    {
        return totalScore;
    }

    public int[] getShotBreakdown()
    {
        return shotBreakdown;
    }
}
