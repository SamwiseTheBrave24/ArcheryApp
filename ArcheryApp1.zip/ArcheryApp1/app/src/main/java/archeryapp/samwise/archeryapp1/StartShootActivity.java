package archeryapp.samwise.archeryapp1;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;


public class StartShootActivity extends AppCompatActivity {

    //public archeryapp.samwise.archeryapp1.Scorecard newScorecard;
    //public Scorecard newScorecard;
    public String location;
    public int totalShotNumber;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start_shoot);
    }

    public void createShoot (View view)
    {

        location = getLocationFromBox();            //This will need to be updated when I add an option to select from previous created shoots (might need to add a new activity)
        //Verify user chose a location
        if (location.isEmpty())
        {
            //Default Android error message code
            Context context = getApplicationContext();
            CharSequence message = "You need to enter a location!";
            int duration = Toast.LENGTH_SHORT;

            Toast toast = Toast.makeText(context, message, duration);
            toast.show();
            //End of Default error message code

            return;                                 //End the function prematurely and have them start over
        }
        totalShotNumber = getShotNumberFromBox ();
        //Verify user chose number of shots for the course

        if (totalShotNumber == 0)
        {
            //Default Android error message code
            Context context = getApplicationContext();
            CharSequence message = "How many targets for the course?!";
            int duration = Toast.LENGTH_SHORT;

            Toast toast = Toast.makeText(context, message, duration);
            toast.show();
            //End of Default error message code

            return;                                //End the function prematurely and have them start over
        }

        //Create a bundle of scorecard info to send to EditScorecardActivity
        Bundle scorecardInfo = new Bundle();        //Bundle of Scorecard info
        scorecardInfo.putString("Location", location);
        scorecardInfo.putInt("TotalShotNumber", totalShotNumber);

        Intent intent = new Intent(this, EditScorecardActivity.class);
        intent.putExtra("ScorecardInfo", scorecardInfo);
        //Log.d ("PST HERE", intent.getExtras().toString());
        startActivity(intent);

    }

    private String getLocationFromBox ()
    {
        EditText editLocation = (EditText) findViewById(R.id.locationInputBox);
        String getLocation = editLocation.getText().toString();
        return getLocation;

    }

    private int getShotNumberFromBox ()
    {
        int getShots;
        EditText shots = (EditText) findViewById(R.id.shotNumberbox);
        String tempShots = shots.getText().toString();
        if (tempShots.isEmpty())
        {
            getShots = 0;
        } else {
            getShots = Integer.parseInt(tempShots);
        }
        return getShots;
    }
}
