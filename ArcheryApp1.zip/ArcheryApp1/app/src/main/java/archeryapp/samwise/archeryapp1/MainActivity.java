package archeryapp.samwise.archeryapp1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void startNewShoot (View view)
        {
            Intent startShoot = new Intent(this, StartShootActivity.class);
            startActivity(startShoot);
    }

    public void testEditScoreActivity (View view)
    {
        Intent test = new Intent(this, EditScorecardActivity.class);
        //startActivity(test);
    }
}
